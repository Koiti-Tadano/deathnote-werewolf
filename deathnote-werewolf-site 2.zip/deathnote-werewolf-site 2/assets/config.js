
// Set your Disqus shortname to enable global anonymous comments.
// 1) Create a site at https://disqus.com/
// 2) Put your shortname below, e.g. 'my-disqus-shortname'
window.SITE_CONFIG = {
  disqusShortname: '' // <- e.g. 'your-shortname' (leave empty to disable)
};
